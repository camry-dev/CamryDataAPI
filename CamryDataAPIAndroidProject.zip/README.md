# CamryDataAPI Android app starter

This is a lightweight Android WebView app for CamryDataAPI. It opens the existing secure website:
https://app.camrydataapi.com/auth/login

Website pages for login, registration, password reset, wallet, transaction history, data, airtime, electricity, cable, exam checker, and recharge-card printing remain provided by the website.

## Important
- This is a starter app project, not a tested APK.
- It requires an internet connection.
- It does not replace the website backend or payment/security systems.
- Before public release, test login, wallet funding, purchases, payment redirects, file uploads, and all links on a real phone.
- The package ID is `com.camrydataapi.app`. If a previous Play Store app uses a different package ID, this will install as a separate app and cannot update the old one.
